package com.jest.socketConnector;

public class SockerConnector {

    private int clientNo;
    private int port;


    public void serveur()
    {

    }

    public void client()
    {

    }
}
