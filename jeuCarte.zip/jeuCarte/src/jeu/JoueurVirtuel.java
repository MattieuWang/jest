package jeu;


import java.util.ArrayList;

public class JoueurVirtuel extends Joueur {

    public JoueurVirtuel(Integer id, String name, String webIp, ArrayList<Carte> cartes) {
        super(id, name, webIp, cartes);
    }
}
