package jeu;

public class SockerConnector {

    public void serveur()
    {

    }

    public void client()
    {

    }
}
