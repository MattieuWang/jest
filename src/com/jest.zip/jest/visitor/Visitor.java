package com.jest.visitor;

import com.jest.joueur.Joueur;

public interface Visitor {
    public void visit(Joueur joueur);
}
